package com.factory.appraisal.vehiclesearchapp.services;

import com.factory.appraisal.vehiclesearchapp.persistence.model.EConfigurationCodes;

public interface EConfigurationCodesService {
    public EConfigurationCodes addConfigCode(EConfigurationCodes eConfigurationCodes);
}
