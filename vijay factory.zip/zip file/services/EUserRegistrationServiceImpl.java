package com.factory.appraisal.vehiclesearchapp.services.crudServices;
//Author:yudhister vijay
import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.UserRegistration;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.*;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EUserRegistration;
import com.factory.appraisal.vehiclesearchapp.repository.EAppraiseVehicleRepo;
import com.factory.appraisal.vehiclesearchapp.repository.EConfigurationCodesRepo;
import com.factory.appraisal.vehiclesearchapp.repository.EDealerRegistrationRepo;
import com.factory.appraisal.vehiclesearchapp.repository.EUserRegistrationRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class EUserRegistrationServiceImpl implements EUserRegistrationService{

    @Autowired
    private EUserRegistrationRepo eUserRegistrationRepo;
    @Autowired
    private EConfigurationCodesRepo eConfigurationCodesRepo;
    @Autowired
    private EDealerRegistrationRepo eDealerRegistrationRepo;
    @Autowired
    private EAppraiseVehicleRepo eAppraiseVehicleRepo;

    @Autowired
    private UserRegistrationMapper userRegistrationMapper;
    @Autowired
    private AppraisalVehicleMapper appraisalVehicleMapper;
    @Autowired
    private DealerRegistrationMapper dealerRegistrationMapper;
    @Autowired
    private ConfigCodesMapper configCodesMapper;
    @Autowired
    private AppraisalTestDrivingStatusMapper appraisalTestDrivingStatusMapper;

    @Override
    public UserRegistration createUser(UserRegistration userRegistration) {
        EUserRegistration eUserRegistration=userRegistrationMapper.dtoToModel(userRegistration);

        eUserRegistration.getDealer().setCreatedOn(new Date());
        eUserRegistration.getRoleConfig().setCreatedOn(new Date());
        eUserRegistration.setCreatedOn(new Date());

        EUserRegistration save=eUserRegistrationRepo.save(eUserRegistration);
        return userRegistrationMapper.modelToDto(save);
    }


    @Override
    public List<UserRegistration> getUsers() {
        List<EUserRegistration> getAll=eUserRegistrationRepo.findAll();
        return userRegistrationMapper.modelToDto(getAll);
    }

    @Override
    public UserRegistration updateUser(Long userId,UserRegistration userRegistration) {
        EUserRegistration users=eUserRegistrationRepo.findById(userId).get();
        if(users!=null){
            if(userRegistration.getValid()!=false) {
                if (userRegistration.getApartmentNumber() != null) {
                    users.setApartmentNumber(userRegistration.getApartmentNumber());
                }
                if (userRegistration.getCity() != null) {
                    users.setCity(userRegistration.getCity());
                }
                if (userRegistration.getEmail() != null) {
                    users.setEmail(userRegistration.getEmail());
                }
                if (userRegistration.getFirstName() != null) {
                    users.setFirstName(userRegistration.getFirstName());
                }
                if (userRegistration.getLastName() != null) {
                    users.setLastName(userRegistration.getLastName());
                }
                if (userRegistration.getPassword() != null) {
                    users.setPassword(userRegistration.getPassword());
                }
                if (userRegistration.getPhoneNumber() != null) {
                    users.setPhoneNumber(userRegistration.getPhoneNumber());
                }
                if (userRegistration.getState() != null) {
                    users.setState(userRegistration.getState());
                }
                if (userRegistration.getStreetAddress() != null) {
                    users.setStreetAddress(userRegistration.getStreetAddress());
                }
                if (userRegistration.getUserName() != null) {
                    users.setUserName(userRegistration.getUserName());
                }
                if (userRegistration.getZipCode() != null) {
                    users.setZipCode(userRegistration.getCity());
                }
            }
        }


        users.setRoleConfig(configCodesMapper.dtoToModel(userRegistration.getRoleConfig()));
        users.getRoleConfig().setModifiedOn(new Date());

        users.setDealer(dealerRegistrationMapper.dtoToModel(userRegistration.getDealer()));
        users.getDealer().setModifiedOn(new Date());

        users.setModifiedOn(new Date());
        eUserRegistrationRepo.save(users);

        UserRegistration userRegistration1= userRegistrationMapper.modelToDto(users);

        userRegistration1.setRoleConfig(configCodesMapper.modelToDto(users.getRoleConfig()));
        userRegistration1.setDealer(dealerRegistrationMapper.modeltoDto(users.getDealer()));

        return userRegistration1;
    }

    @Override
    public String removeUserRegistration(Long userId) {
        EUserRegistration byUserId = eUserRegistrationRepo.findByUserId(userId);
        if(byUserId!=null && byUserId.getValid()==true) {
            byUserId.setValid(false);
            eUserRegistrationRepo.save(byUserId);

            return "deleted";
        }
        else
            throw new RuntimeException("Did not find UserDetails of  - " + userId);

    }

    @Override
    public List<UserRegistration> getUsersPageWise(Integer pageNumber, Integer pageSize) {

        Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by("createdOn").descending());
        Page<EUserRegistration> pageResult = eUserRegistrationRepo.findAllByValidIsTrueOrderByCreatedOnDesc(pageable);

        List<EUserRegistration> apv = pageResult.toList();
        List<UserRegistration> userRegistrationsDtos= userRegistrationMapper.modelsToDtos(apv);
        return userRegistrationsDtos;
    }
}

