package com.factory.appraisal.vehiclesearchapp.services.auditService;

import java.util.ArrayList;
import java.util.Map;

public interface AuditUserRegistrationService {
    ArrayList<Map<String,Object>> getAuditedData(String field,Long id,Integer offset);
}
