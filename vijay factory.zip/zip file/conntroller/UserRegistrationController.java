package com.factory.appraisal.vehiclesearchapp.controller;
//Author:yudhister vijay
import com.factory.appraisal.vehiclesearchapp.persistence.dto.UserRegistration;
import com.factory.appraisal.vehiclesearchapp.services.crudServices.EUserRegistrationServiceImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/api/userReg")
@Api(value = "UserRegistrationController" , description = "Operations in User Registration")
public class UserRegistrationController {
    @Autowired
    private EUserRegistrationServiceImpl eUserRegistrationService;
    @ApiOperation(value = "Add users in database")

    @PostMapping("/createUser")
    public ResponseEntity<UserRegistration> postUserRegistration(@RequestBody @Valid UserRegistration userRegistration){
        return new ResponseEntity<>(eUserRegistrationService.createUser(userRegistration), HttpStatus.CREATED);
    }
    @GetMapping("/getAllUsers")
    public ResponseEntity<List<UserRegistration>> getAllUsers(){
        return new ResponseEntity<>(eUserRegistrationService.getUsers(),HttpStatus.OK);
    }

    @GetMapping("/getUsersByPageWise/{pageNumber}/{pageSize}")
    public ResponseEntity<List<UserRegistration>> getUsersPageWise(@PathVariable @Min(0) Integer pageNumber, @PathVariable @Min(1) @Max(100) Integer pageSize) {
        try {
            if (pageNumber < 0) {
                throw new IllegalArgumentException("Page number cannot be negative.");
            }
            if (pageSize < 1 || pageSize > 100) {
                throw new IllegalArgumentException("Page size must be between 1 and 100.");
            }
            List<UserRegistration> ur = eUserRegistrationService.getUsersPageWise(pageNumber, pageSize);
            return new ResponseEntity<>(ur, HttpStatus.ACCEPTED);
        } catch (IllegalArgumentException e) {
            String message="invalid page number or page size is provided, page number and size should be positive";
            return ResponseEntity.badRequest().body((List<UserRegistration>) Collections.singletonMap("message", message));
        }catch (Exception e){
            //TO HANDLE OTHER EXCEPTIONS
            String message="an occurred while retrieving user details";
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body((List<UserRegistration>) Collections.singletonMap("message", message));
        }

    }

    @PutMapping("/updateUser/{userId}")
    public ResponseEntity<UserRegistration> updateUser(@PathVariable Long userId, @RequestBody @Valid UserRegistration userRegistration){
        return new ResponseEntity<>(eUserRegistrationService.updateUser(userId,userRegistration),
                HttpStatus.ACCEPTED
        );
    }

    @DeleteMapping("/deleteUser/{userId}")
    public String deleteUser(@PathVariable Long userId){
        return  eUserRegistrationService.removeUserRegistration(userId);
    }

}
